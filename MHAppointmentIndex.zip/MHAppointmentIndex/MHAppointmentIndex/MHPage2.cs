﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MHAppointmentIndex
{
    public partial class MHPage2 : Form
    {
        public MHPage2()
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e) // ANSWER FORM BUTTON
        {
            this.Hide(); // magh-hide current page
            MHPage3 f3 = new MHPage3();
            f3.ShowDialog();
            this.Close();
        }
        private void button1_Click(object sender, EventArgs e) // ADMIN BUTTON
        {
            this.Hide(); // magh-hide current page
            MHAPage3Login fL = new MHAPage3Login();
            fL.ShowDialog();
            this.Close();
        }
    }
}
