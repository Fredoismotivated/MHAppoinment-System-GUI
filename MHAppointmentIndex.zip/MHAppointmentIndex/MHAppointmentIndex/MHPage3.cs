﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MHAppointmentIndex
{
    public partial class MHPage3 : Form
    {

        MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;database=mhpatients;port=3306;username=root;password=");
        public MHPage3()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) //BACK BUTTON
        {
            this.Hide();
            MHPage2 f2 = new MHPage2();
            f2.ShowDialog();
            this.Close();
        }
        private void SurnameTXTBX_TextChanged(object sender, EventArgs e) //SURNAME TEXTBOX
        {

        }

        private void FirstnameTXTBX_TextChanged(object sender, EventArgs e) //FIRSTNAME TEXTBOX
        {

        }
        private void GenderComboBox_SelectedIndexChanged(object sender, EventArgs e) //SEX COMBO BOX
        {

        }
        private void AgeTXTBX_TextChanged(object sender, EventArgs e) //AGE TEXTBOX
        {

        }
        private void AddressTXTBX_TextChanged(object sender, EventArgs e) //ADDRESS TEXTBOX
        {

        }
        private void ContactNoTXTBX_TextChanged(object sender, EventArgs e) //CONTACT NO TEXT BOX
        {

        }

        private void TimeComboBox_SelectedIndexChanged(object sender, EventArgs e) //SCHEDULE COMBO BOX
        {

        }

        private void EmailAddTXTBX_TextChanged(object sender, EventArgs e) //EMAIL TEXT BOX
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e) //CALENDAR
        {
            // if else condition para macheck kung weekends yung selected, tatawag ng function para maiba contents ng combo box
            if (monthCalendar1.SelectionStart.DayOfWeek == DayOfWeek.Saturday || monthCalendar1.SelectionStart.DayOfWeek == DayOfWeek.Sunday)
            {
                // kung weekend days yung selected tatawagin tong function na to para maiba yung laman ng combo box para sa sched ng weekends
                UpdateTimeComboBoxOptionsForWeekend();
            }
            else
            {
                // reset function para mabalik sa default options pag weekdays
                ResetTimeComboBoxOptions();
            }
        }
        private void UpdateTimeComboBoxOptionsForWeekend()
        {
            // icclear neto kung anong options tas yung sunod na functions iibahin yung laman
            TimeComboBox.Items.Clear();

            // sasalpakan ng bagong option sa combo box pag weekends
            TimeComboBox.Items.Add("8 am - 9 am");
            TimeComboBox.Items.Add("9 am - 10 am");
            TimeComboBox.Items.Add("10 am - 11 am");
            TimeComboBox.Items.Add("12:30 pm - 1 pm");

            // nagseset ng default selected na item
            TimeComboBox.SelectedIndex = 0;
        }

        private void ResetTimeComboBoxOptions()
        {
            // pangclear ng options sa combo box
            TimeComboBox.Items.Clear();

            // eto yung naglalagay ng normal options pag weekdays
            TimeComboBox.Items.Add("8 am - 9 am");
            TimeComboBox.Items.Add("9 am - 10 am");
            TimeComboBox.Items.Add("10 am - 11 am");
            TimeComboBox.Items.Add("1 pm - 2 pm");
            TimeComboBox.Items.Add("2 pm - 3 pm");
            TimeComboBox.Items.Add("3 pm - 4 pm");

            // pangdefault lang
            TimeComboBox.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e) //SUBMIT BUTTON
        {
            try
            {
                // pangextract ng values galing sa mga text at combo box
                string surname = SurnameTXTBX.Text;
                string firstname = FirstnameTXTBX.Text;

                if (!IsFirstLetterCapital(SurnameTXTBX.Text) || !IsFirstLetterCapital(FirstnameTXTBX.Text))
                {
                    MessageBox.Show("Surname and Firstname should start with a capital letter.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string sex = GenderComboBox.Text;
                int age = Convert.ToInt32(AgeTXTBX.Text);
                string contactStr = ContactNoTXTBX.Text;
                Int64 contact;

                // if condition - dapat 11 digits para valid, kung hindi 11 digits mage-error, 11 digits kase 11 digits number sa bansa natin
                if (contactStr.Length != 11 || !Int64.TryParse(contactStr, out contact))
                {
                    MessageBox.Show("Please enter a valid 11-digit contact number.", "Invalid Contact Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // kung nameet yung condition edi hindi mage-error
                }

                // panibagong condition dapat may 09 yung inputted ng user para masure na proper numbeer na maccontact mailagay
                string firstTwoDigits = contactStr.Length >= 2 ? contactStr.Substring(0, 2) : "";
                if (firstTwoDigits != "09")
                {
                    MessageBox.Show("Invalid phone number. The first two digits must be '09'.", "Invalid Phone Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string email = EmailAddTXTBX.Text;
                string address = AddressTXTBX.Text;

                //Pang check kung may laman address
                if (string.IsNullOrEmpty(AddressTXTBX.Text))
                {
                    MessageBox.Show("Please enter a valid address.", "Empty Address", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string timeRange = TimeComboBox.Text; // Assuming TimeComboBox now represents the time range

                // if condition - dapat may @ tsaka dot yung ininput ng user kase may dot at @ mga email
                if (!email.Contains("@") || !email.Contains("."))
                {
                    MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    return;
                }
                // if condition - dapat may napili yung user na time sa combo box, kung wala edi mage-error
                if (string.IsNullOrEmpty(timeRange))
                {
                    MessageBox.Show("Please select a time range.", "No Time Range Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DateTime selectedDate = monthCalendar1.SelectionRange.Start;

                // Using parameterized query to prevent SQL injection
                string query = "INSERT INTO patientappointment (surname, firstname, Sex, age, contact, email, address, TimeRange, Date) " +
                               "VALUES (@surname, @firstname, @Sex, @age, @contact, @email, @address, @TimeRange, @Date)";

                using (MySqlConnection connection = new MySqlConnection("datasource=127.0.0.1;database=mhpatients;port=3306;username=root;password="))
                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    // Adding parameters to the query
                    cmd.Parameters.Add("@surname", MySqlDbType.VarChar).Value = surname;
                    cmd.Parameters.Add("@firstname", MySqlDbType.VarChar).Value = firstname;
                    cmd.Parameters.Add("@Sex", MySqlDbType.VarChar).Value = sex;
                    cmd.Parameters.Add("@age", MySqlDbType.Int32).Value = age;
                    cmd.Parameters.Add("@contact", MySqlDbType.Int64).Value = contact;
                    cmd.Parameters.Add("@email", MySqlDbType.VarChar).Value = email;
                    cmd.Parameters.Add("@address", MySqlDbType.VarChar).Value = address;
                    cmd.Parameters.Add("@TimeRange", MySqlDbType.VarChar).Value = timeRange;
                    cmd.Parameters.Add("@Date", MySqlDbType.Date).Value = selectedDate.Date;

                    connection.Open();

                    // Execute the query
                    cmd.ExecuteNonQuery();

                    // gumawa ako bukod na function para magclear lahat ng textbox at combobox pagkatapos ng successful entry ng data
                    ClearTextBoxes();

                    MessageBox.Show("Data successfully inserted into the database.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }


        }
        private bool IsFirstLetterCapital(string input) //Method para macheck yung capital letters sa firstname at surname
        {
            if (string.IsNullOrEmpty(input))
            {
                return false;
            }

            char firstChar = input[0];
            return char.IsUpper(firstChar);
        }
        private void ClearTextBoxes() // eto yung function na tinawag para magclear
        {
            SurnameTXTBX.Clear();
            FirstnameTXTBX.Clear();
            GenderComboBox.SelectedIndex = -1; // nahirapan ako dito -ctto google
            AgeTXTBX.Clear();
            ContactNoTXTBX.Clear();
            EmailAddTXTBX.Clear();
            AddressTXTBX.Clear();
            TimeComboBox.SelectedIndex = -1; // nahirapan ako dito -ctto google
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
