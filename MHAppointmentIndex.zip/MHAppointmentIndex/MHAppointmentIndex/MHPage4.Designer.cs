﻿namespace MHAppointmentIndex
{
    partial class MHPage4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MHPage4));
            form1BindingSource = new BindingSource(components);
            APPOINTMENTButton1 = new Button();
            CHARTButton2 = new Button();
            RECORDButton3 = new Button();
            Button1label = new Label();
            Button2label = new Label();
            Button3label = new Label();
            imageList1 = new ImageList(components);
            LobbyPicture = new PictureBox();
            APPOINTMENTPanel1 = new Panel();
            AppointmentDataGridView = new DataGridView();
            Panel1PatientInfoBox = new PictureBox();
            CHARTPanel2 = new Panel();
            SelfharmCheckbox = new CheckBox();
            SleepDisorderCheckBox = new CheckBox();
            PersonalityandBehaviorDisorderCheckbox = new CheckBox();
            SubstanceRelatedCheckBox = new CheckBox();
            ICandADCheckBox = new CheckBox();
            label31 = new Label();
            label30 = new Label();
            label29 = new Label();
            label28 = new Label();
            label27 = new Label();
            label26 = new Label();
            label25 = new Label();
            label24 = new Label();
            label23 = new Label();
            label22 = new Label();
            EatingDisorderCheckBox = new CheckBox();
            PsychoticDisorderCheckBox = new CheckBox();
            label21 = new Label();
            label20 = new Label();
            label19 = new Label();
            label18 = new Label();
            PTSDCheckBox = new CheckBox();
            OCDCheckBox = new CheckBox();
            label17 = new Label();
            label16 = new Label();
            label9 = new Label();
            label8 = new Label();
            SocialAnxietyCheckBox = new CheckBox();
            PanicDisorderCheckBox = new CheckBox();
            BipolarDisorderCheckBox = new CheckBox();
            DepressionCheckBox = new CheckBox();
            CHARTPanel2DoneButton = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            panel1 = new Panel();
            PatientTimeLabel = new Label();
            PatientDateLabel = new Label();
            label32 = new Label();
            ChartApointmentTimeComboBox = new ComboBox();
            ChartDatePicker = new DateTimePicker();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label10 = new Label();
            label2 = new Label();
            PatientNumberTextBox = new TextBox();
            label1 = new Label();
            RecordPanel3 = new Panel();
            label11 = new Label();
            RecordButtonHome = new Button();
            pictureBox1 = new PictureBox();
            RecordGridView = new DataGridView();
            BANNER1Box = new PictureBox();
            PatientChartCaution = new PictureBox();
            PatientChartCautionLabel = new Label();
            contextMenuStrip1 = new ContextMenuStrip(components);
            mySqlCommand1 = new MySql.Data.MySqlClient.MySqlCommand();
            ((System.ComponentModel.ISupportInitialize)form1BindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)LobbyPicture).BeginInit();
            APPOINTMENTPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)AppointmentDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Panel1PatientInfoBox).BeginInit();
            CHARTPanel2.SuspendLayout();
            panel1.SuspendLayout();
            RecordPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RecordGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BANNER1Box).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PatientChartCaution).BeginInit();
            SuspendLayout();
            // 
            // form1BindingSource
            // 
            form1BindingSource.DataSource = typeof(Form1);
            // 
            // APPOINTMENTButton1
            // 
            APPOINTMENTButton1.BackColor = Color.Transparent;
            APPOINTMENTButton1.BackgroundImage = (Image)resources.GetObject("APPOINTMENTButton1.BackgroundImage");
            APPOINTMENTButton1.BackgroundImageLayout = ImageLayout.None;
            APPOINTMENTButton1.Location = new Point(25, 92);
            APPOINTMENTButton1.Name = "APPOINTMENTButton1";
            APPOINTMENTButton1.Size = new Size(182, 40);
            APPOINTMENTButton1.TabIndex = 0;
            APPOINTMENTButton1.UseVisualStyleBackColor = false;
            APPOINTMENTButton1.Click += APPOINTMENTButton1_Click_1;
            // 
            // CHARTButton2
            // 
            CHARTButton2.BackColor = Color.Transparent;
            CHARTButton2.BackgroundImage = (Image)resources.GetObject("CHARTButton2.BackgroundImage");
            CHARTButton2.BackgroundImageLayout = ImageLayout.None;
            CHARTButton2.Location = new Point(25, 148);
            CHARTButton2.Name = "CHARTButton2";
            CHARTButton2.Size = new Size(182, 40);
            CHARTButton2.TabIndex = 1;
            CHARTButton2.UseVisualStyleBackColor = false;
            CHARTButton2.Click += CHARTButton2_Click_1;
            // 
            // RECORDButton3
            // 
            RECORDButton3.BackColor = Color.Transparent;
            RECORDButton3.BackgroundImage = (Image)resources.GetObject("RECORDButton3.BackgroundImage");
            RECORDButton3.BackgroundImageLayout = ImageLayout.None;
            RECORDButton3.Location = new Point(25, 205);
            RECORDButton3.Name = "RECORDButton3";
            RECORDButton3.Size = new Size(182, 40);
            RECORDButton3.TabIndex = 2;
            RECORDButton3.UseVisualStyleBackColor = false;
            RECORDButton3.Click += RECORDButton3_Click_1;
            // 
            // Button1label
            // 
            Button1label.AutoSize = true;
            Button1label.BackColor = Color.Transparent;
            Button1label.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button1label.Location = new Point(3, 85);
            Button1label.Name = "Button1label";
            Button1label.Size = new Size(29, 47);
            Button1label.TabIndex = 3;
            Button1label.Text = "·";
            Button1label.Click += Button1label_Click;
            // 
            // Button2label
            // 
            Button2label.AutoSize = true;
            Button2label.BackColor = Color.Transparent;
            Button2label.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button2label.Location = new Point(3, 141);
            Button2label.Name = "Button2label";
            Button2label.Size = new Size(29, 47);
            Button2label.TabIndex = 4;
            Button2label.Text = "·";
            Button2label.Click += Button2label_Click;
            // 
            // Button3label
            // 
            Button3label.AutoSize = true;
            Button3label.BackColor = Color.Transparent;
            Button3label.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button3label.Location = new Point(3, 198);
            Button3label.Name = "Button3label";
            Button3label.Size = new Size(29, 47);
            Button3label.TabIndex = 5;
            Button3label.Text = "·";
            Button3label.Click += Button3label_Click;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // LobbyPicture
            // 
            LobbyPicture.BackColor = Color.Transparent;
            LobbyPicture.BackgroundImage = (Image)resources.GetObject("LobbyPicture.BackgroundImage");
            LobbyPicture.BackgroundImageLayout = ImageLayout.Stretch;
            LobbyPicture.Location = new Point(269, 53);
            LobbyPicture.Name = "LobbyPicture";
            LobbyPicture.Size = new Size(629, 371);
            LobbyPicture.TabIndex = 6;
            LobbyPicture.TabStop = false;
            LobbyPicture.Click += LobbyPicture_Click;
            // 
            // APPOINTMENTPanel1
            // 
            APPOINTMENTPanel1.BackColor = Color.FromArgb(99, 133, 105);
            APPOINTMENTPanel1.Controls.Add(AppointmentDataGridView);
            APPOINTMENTPanel1.Controls.Add(Panel1PatientInfoBox);
            APPOINTMENTPanel1.Location = new Point(228, 53);
            APPOINTMENTPanel1.Name = "APPOINTMENTPanel1";
            APPOINTMENTPanel1.Size = new Size(766, 371);
            APPOINTMENTPanel1.TabIndex = 7;
            APPOINTMENTPanel1.Paint += APPOINTMENTPanel1_Paint;
            // 
            // AppointmentDataGridView
            // 
            AppointmentDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AppointmentDataGridView.Location = new Point(3, 32);
            AppointmentDataGridView.Name = "AppointmentDataGridView";
            AppointmentDataGridView.RowTemplate.Height = 25;
            AppointmentDataGridView.Size = new Size(760, 336);
            AppointmentDataGridView.TabIndex = 1;
            AppointmentDataGridView.CellContentClick += AppointmentDataGridView_CellContentClick_1;
            // 
            // Panel1PatientInfoBox
            // 
            Panel1PatientInfoBox.BackColor = Color.Transparent;
            Panel1PatientInfoBox.BackgroundImage = (Image)resources.GetObject("Panel1PatientInfoBox.BackgroundImage");
            Panel1PatientInfoBox.BackgroundImageLayout = ImageLayout.None;
            Panel1PatientInfoBox.Location = new Point(0, 0);
            Panel1PatientInfoBox.Name = "Panel1PatientInfoBox";
            Panel1PatientInfoBox.Size = new Size(219, 33);
            Panel1PatientInfoBox.TabIndex = 0;
            Panel1PatientInfoBox.TabStop = false;
            // 
            // CHARTPanel2
            // 
            CHARTPanel2.BackColor = Color.FromArgb(99, 133, 105);
            CHARTPanel2.Controls.Add(SelfharmCheckbox);
            CHARTPanel2.Controls.Add(SleepDisorderCheckBox);
            CHARTPanel2.Controls.Add(PersonalityandBehaviorDisorderCheckbox);
            CHARTPanel2.Controls.Add(SubstanceRelatedCheckBox);
            CHARTPanel2.Controls.Add(ICandADCheckBox);
            CHARTPanel2.Controls.Add(label31);
            CHARTPanel2.Controls.Add(label30);
            CHARTPanel2.Controls.Add(label29);
            CHARTPanel2.Controls.Add(label28);
            CHARTPanel2.Controls.Add(label27);
            CHARTPanel2.Controls.Add(label26);
            CHARTPanel2.Controls.Add(label25);
            CHARTPanel2.Controls.Add(label24);
            CHARTPanel2.Controls.Add(label23);
            CHARTPanel2.Controls.Add(label22);
            CHARTPanel2.Controls.Add(EatingDisorderCheckBox);
            CHARTPanel2.Controls.Add(PsychoticDisorderCheckBox);
            CHARTPanel2.Controls.Add(label21);
            CHARTPanel2.Controls.Add(label20);
            CHARTPanel2.Controls.Add(label19);
            CHARTPanel2.Controls.Add(label18);
            CHARTPanel2.Controls.Add(PTSDCheckBox);
            CHARTPanel2.Controls.Add(OCDCheckBox);
            CHARTPanel2.Controls.Add(label17);
            CHARTPanel2.Controls.Add(label16);
            CHARTPanel2.Controls.Add(label9);
            CHARTPanel2.Controls.Add(label8);
            CHARTPanel2.Controls.Add(SocialAnxietyCheckBox);
            CHARTPanel2.Controls.Add(PanicDisorderCheckBox);
            CHARTPanel2.Controls.Add(BipolarDisorderCheckBox);
            CHARTPanel2.Controls.Add(DepressionCheckBox);
            CHARTPanel2.Controls.Add(CHARTPanel2DoneButton);
            CHARTPanel2.Controls.Add(label7);
            CHARTPanel2.Controls.Add(label6);
            CHARTPanel2.Controls.Add(label5);
            CHARTPanel2.Controls.Add(label4);
            CHARTPanel2.Controls.Add(label3);
            CHARTPanel2.Controls.Add(panel1);
            CHARTPanel2.Controls.Add(label2);
            CHARTPanel2.Controls.Add(PatientNumberTextBox);
            CHARTPanel2.Controls.Add(label1);
            CHARTPanel2.Location = new Point(228, 53);
            CHARTPanel2.Name = "CHARTPanel2";
            CHARTPanel2.Size = new Size(766, 371);
            CHARTPanel2.TabIndex = 1;
            CHARTPanel2.Paint += CHARTPanel2_Paint;
            // 
            // SelfharmCheckbox
            // 
            SelfharmCheckbox.AutoSize = true;
            SelfharmCheckbox.BackColor = Color.Transparent;
            SelfharmCheckbox.Location = new Point(601, 313);
            SelfharmCheckbox.Name = "SelfharmCheckbox";
            SelfharmCheckbox.Size = new Size(15, 14);
            SelfharmCheckbox.TabIndex = 50;
            SelfharmCheckbox.UseVisualStyleBackColor = false;
            SelfharmCheckbox.CheckedChanged += SelfharmCheckbox_CheckedChanged;
            // 
            // SleepDisorderCheckBox
            // 
            SleepDisorderCheckBox.AutoSize = true;
            SleepDisorderCheckBox.BackColor = Color.Transparent;
            SleepDisorderCheckBox.Location = new Point(601, 276);
            SleepDisorderCheckBox.Name = "SleepDisorderCheckBox";
            SleepDisorderCheckBox.Size = new Size(15, 14);
            SleepDisorderCheckBox.TabIndex = 49;
            SleepDisorderCheckBox.UseVisualStyleBackColor = false;
            SleepDisorderCheckBox.CheckedChanged += SleepDisorderCheckBox_CheckedChanged;
            // 
            // PersonalityandBehaviorDisorderCheckbox
            // 
            PersonalityandBehaviorDisorderCheckbox.AutoSize = true;
            PersonalityandBehaviorDisorderCheckbox.BackColor = Color.Transparent;
            PersonalityandBehaviorDisorderCheckbox.Location = new Point(601, 238);
            PersonalityandBehaviorDisorderCheckbox.Name = "PersonalityandBehaviorDisorderCheckbox";
            PersonalityandBehaviorDisorderCheckbox.Size = new Size(15, 14);
            PersonalityandBehaviorDisorderCheckbox.TabIndex = 48;
            PersonalityandBehaviorDisorderCheckbox.UseVisualStyleBackColor = false;
            PersonalityandBehaviorDisorderCheckbox.CheckedChanged += PersonalityandBehaviorDisorderCheckbox_CheckedChanged;
            // 
            // SubstanceRelatedCheckBox
            // 
            SubstanceRelatedCheckBox.AutoSize = true;
            SubstanceRelatedCheckBox.BackColor = Color.Transparent;
            SubstanceRelatedCheckBox.Location = new Point(601, 201);
            SubstanceRelatedCheckBox.Name = "SubstanceRelatedCheckBox";
            SubstanceRelatedCheckBox.Size = new Size(15, 14);
            SubstanceRelatedCheckBox.TabIndex = 47;
            SubstanceRelatedCheckBox.UseVisualStyleBackColor = false;
            SubstanceRelatedCheckBox.CheckedChanged += SubstanceRelatedCheckBox_CheckedChanged;
            // 
            // ICandADCheckBox
            // 
            ICandADCheckBox.AutoSize = true;
            ICandADCheckBox.BackColor = Color.Transparent;
            ICandADCheckBox.Location = new Point(601, 166);
            ICandADCheckBox.Name = "ICandADCheckBox";
            ICandADCheckBox.Size = new Size(15, 14);
            ICandADCheckBox.TabIndex = 46;
            ICandADCheckBox.UseVisualStyleBackColor = false;
            ICandADCheckBox.CheckedChanged += ICandADCheckBox_CheckedChanged;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.BackColor = Color.Transparent;
            label31.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label31.ForeColor = Color.FromArgb(238, 231, 218);
            label31.Location = new Point(308, 334);
            label31.Name = "label31";
            label31.Size = new Size(221, 14);
            label31.TabIndex = 45;
            label31.Text = "10. Self-Harm or Suicidal Thoughts\n";
            label31.TextAlign = ContentAlignment.MiddleCenter;
            label31.UseMnemonic = false;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.BackColor = Color.Transparent;
            label30.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label30.ForeColor = Color.FromArgb(238, 231, 218);
            label30.Location = new Point(308, 313);
            label30.Name = "label30";
            label30.Size = new Size(224, 16);
            label30.TabIndex = 44;
            label30.Text = "Self-Harm and Suicidal Thoughts: ";
            label30.TextAlign = ContentAlignment.MiddleCenter;
            label30.UseMnemonic = false;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.BackColor = Color.Transparent;
            label29.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label29.ForeColor = Color.FromArgb(238, 231, 218);
            label29.Location = new Point(308, 297);
            label29.Name = "label29";
            label29.Size = new Size(121, 14);
            label29.TabIndex = 43;
            label29.Text = "9. Sleep Disorders ";
            label29.TextAlign = ContentAlignment.MiddleCenter;
            label29.UseMnemonic = false;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.BackColor = Color.Transparent;
            label28.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label28.ForeColor = Color.FromArgb(238, 231, 218);
            label28.Location = new Point(308, 276);
            label28.Name = "label28";
            label28.Size = new Size(117, 16);
            label28.TabIndex = 42;
            label28.Text = "Sleep Disorders: ";
            label28.TextAlign = ContentAlignment.MiddleCenter;
            label28.UseMnemonic = false;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.BackColor = Color.Transparent;
            label27.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label27.ForeColor = Color.FromArgb(238, 231, 218);
            label27.Location = new Point(308, 257);
            label27.Name = "label27";
            label27.Size = new Size(152, 14);
            label27.TabIndex = 41;
            label27.Text = "8. Personality Disorders";
            label27.TextAlign = ContentAlignment.MiddleCenter;
            label27.UseMnemonic = false;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.BackColor = Color.Transparent;
            label26.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label26.ForeColor = Color.FromArgb(238, 231, 218);
            label26.Location = new Point(308, 238);
            label26.Name = "label26";
            label26.Size = new Size(244, 16);
            label26.TabIndex = 40;
            label26.Text = "Personality and Behavior Disorders: ";
            label26.TextAlign = ContentAlignment.MiddleCenter;
            label26.UseMnemonic = false;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.BackColor = Color.Transparent;
            label25.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label25.ForeColor = Color.FromArgb(238, 231, 218);
            label25.Location = new Point(308, 221);
            label25.Name = "label25";
            label25.Size = new Size(173, 14);
            label25.TabIndex = 39;
            label25.Text = "7. Substance Use Disorders";
            label25.TextAlign = ContentAlignment.MiddleCenter;
            label25.UseMnemonic = false;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.BackColor = Color.Transparent;
            label24.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label24.ForeColor = Color.FromArgb(238, 231, 218);
            label24.Location = new Point(308, 198);
            label24.Name = "label24";
            label24.Size = new Size(202, 16);
            label24.TabIndex = 38;
            label24.Text = "Substance-Related Disorders:";
            label24.TextAlign = ContentAlignment.MiddleCenter;
            label24.UseMnemonic = false;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.BackColor = Color.Transparent;
            label23.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label23.ForeColor = Color.FromArgb(238, 231, 218);
            label23.Location = new Point(308, 183);
            label23.Name = "label23";
            label23.Size = new Size(321, 14);
            label23.TabIndex = 37;
            label23.Text = "6. Attention-Deficit/Hyperactivity Disorder (ADHD)";
            label23.TextAlign = ContentAlignment.MiddleCenter;
            label23.UseMnemonic = false;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.BackColor = Color.Transparent;
            label22.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label22.ForeColor = Color.FromArgb(238, 231, 218);
            label22.Location = new Point(308, 164);
            label22.Name = "label22";
            label22.Size = new Size(278, 16);
            label22.TabIndex = 36;
            label22.Text = "Impulse Control and Attention Disorders: ";
            label22.TextAlign = ContentAlignment.MiddleCenter;
            label22.UseMnemonic = false;
            // 
            // EatingDisorderCheckBox
            // 
            EatingDisorderCheckBox.AutoSize = true;
            EatingDisorderCheckBox.BackColor = Color.Transparent;
            EatingDisorderCheckBox.Location = new Point(268, 318);
            EatingDisorderCheckBox.Name = "EatingDisorderCheckBox";
            EatingDisorderCheckBox.Size = new Size(15, 14);
            EatingDisorderCheckBox.TabIndex = 35;
            EatingDisorderCheckBox.UseVisualStyleBackColor = false;
            EatingDisorderCheckBox.CheckedChanged += EatingDisorderCheckBox_CheckedChanged;
            // 
            // PsychoticDisorderCheckBox
            // 
            PsychoticDisorderCheckBox.AutoSize = true;
            PsychoticDisorderCheckBox.BackColor = Color.Transparent;
            PsychoticDisorderCheckBox.Location = new Point(268, 258);
            PsychoticDisorderCheckBox.Name = "PsychoticDisorderCheckBox";
            PsychoticDisorderCheckBox.Size = new Size(15, 14);
            PsychoticDisorderCheckBox.TabIndex = 34;
            PsychoticDisorderCheckBox.UseVisualStyleBackColor = false;
            PsychoticDisorderCheckBox.CheckedChanged += PsychoticDisorderCheckBox_CheckedChanged;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = Color.Transparent;
            label21.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label21.ForeColor = Color.FromArgb(238, 231, 218);
            label21.Location = new Point(3, 317);
            label21.Name = "label21";
            label21.Size = new Size(127, 14);
            label21.TabIndex = 33;
            label21.Text = "5. Eating Disorders:";
            label21.TextAlign = ContentAlignment.MiddleCenter;
            label21.UseMnemonic = false;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = Color.Transparent;
            label20.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label20.ForeColor = Color.FromArgb(238, 231, 218);
            label20.Location = new Point(19, 295);
            label20.Name = "label20";
            label20.Size = new Size(200, 16);
            label20.TabIndex = 32;
            label20.Text = "Eating and Weight Disorders: ";
            label20.TextAlign = ContentAlignment.MiddleCenter;
            label20.UseMnemonic = false;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.Transparent;
            label19.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label19.ForeColor = Color.FromArgb(238, 231, 218);
            label19.Location = new Point(3, 276);
            label19.Name = "label19";
            label19.Size = new Size(108, 14);
            label19.TabIndex = 31;
            label19.Text = "4. Schizophrenia\r\n";
            label19.TextAlign = ContentAlignment.MiddleCenter;
            label19.UseMnemonic = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = Color.Transparent;
            label18.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label18.ForeColor = Color.FromArgb(238, 231, 218);
            label18.Location = new Point(19, 255);
            label18.Name = "label18";
            label18.Size = new Size(144, 16);
            label18.TabIndex = 30;
            label18.Text = "Psychotic Disorders: ";
            label18.TextAlign = ContentAlignment.MiddleCenter;
            label18.UseMnemonic = false;
            // 
            // PTSDCheckBox
            // 
            PTSDCheckBox.AutoSize = true;
            PTSDCheckBox.BackColor = Color.Transparent;
            PTSDCheckBox.Location = new Point(268, 240);
            PTSDCheckBox.Name = "PTSDCheckBox";
            PTSDCheckBox.Size = new Size(15, 14);
            PTSDCheckBox.TabIndex = 29;
            PTSDCheckBox.UseVisualStyleBackColor = false;
            PTSDCheckBox.CheckedChanged += PTSDCheckBox_CheckedChanged;
            // 
            // OCDCheckBox
            // 
            OCDCheckBox.AutoSize = true;
            OCDCheckBox.BackColor = Color.Transparent;
            OCDCheckBox.Location = new Point(268, 221);
            OCDCheckBox.Name = "OCDCheckBox";
            OCDCheckBox.Size = new Size(15, 14);
            OCDCheckBox.TabIndex = 28;
            OCDCheckBox.UseVisualStyleBackColor = false;
            OCDCheckBox.CheckedChanged += OCDCheckBox_CheckedChanged;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label17.ForeColor = Color.FromArgb(238, 231, 218);
            label17.Location = new Point(3, 238);
            label17.Name = "label17";
            label17.Size = new Size(259, 14);
            label17.TabIndex = 27;
            label17.Text = "4. Post-Traumatic Stress Disorder (PTSD)";
            label17.TextAlign = ContentAlignment.MiddleCenter;
            label17.UseMnemonic = false;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label16.ForeColor = Color.FromArgb(238, 231, 218);
            label16.Location = new Point(3, 220);
            label16.Name = "label16";
            label16.Size = new Size(251, 14);
            label16.TabIndex = 26;
            label16.Text = "3. Obsessive-Compulsive Disorder (OCD)";
            label16.TextAlign = ContentAlignment.MiddleCenter;
            label16.UseMnemonic = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.FromArgb(238, 231, 218);
            label9.Location = new Point(3, 200);
            label9.Name = "label9";
            label9.Size = new Size(164, 14);
            label9.TabIndex = 25;
            label9.Text = "2. Social Anxiety Disorder";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            label9.UseMnemonic = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(238, 231, 218);
            label8.Location = new Point(3, 182);
            label8.Name = "label8";
            label8.Size = new Size(106, 14);
            label8.TabIndex = 24;
            label8.Text = "1.Panic Disorder\n";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            label8.UseMnemonic = false;
            // 
            // SocialAnxietyCheckBox
            // 
            SocialAnxietyCheckBox.AutoSize = true;
            SocialAnxietyCheckBox.BackColor = Color.Transparent;
            SocialAnxietyCheckBox.Location = new Point(268, 198);
            SocialAnxietyCheckBox.Name = "SocialAnxietyCheckBox";
            SocialAnxietyCheckBox.Size = new Size(15, 14);
            SocialAnxietyCheckBox.TabIndex = 23;
            SocialAnxietyCheckBox.UseVisualStyleBackColor = false;
            SocialAnxietyCheckBox.CheckedChanged += SocialAnxietyCheckBox_CheckedChanged;
            // 
            // PanicDisorderCheckBox
            // 
            PanicDisorderCheckBox.AutoSize = true;
            PanicDisorderCheckBox.BackColor = Color.Transparent;
            PanicDisorderCheckBox.Location = new Point(268, 178);
            PanicDisorderCheckBox.Name = "PanicDisorderCheckBox";
            PanicDisorderCheckBox.Size = new Size(15, 14);
            PanicDisorderCheckBox.TabIndex = 22;
            PanicDisorderCheckBox.UseVisualStyleBackColor = false;
            PanicDisorderCheckBox.CheckedChanged += PanicDisorderCheckBox_CheckedChanged;
            // 
            // BipolarDisorderCheckBox
            // 
            BipolarDisorderCheckBox.AutoSize = true;
            BipolarDisorderCheckBox.BackColor = Color.Transparent;
            BipolarDisorderCheckBox.Location = new Point(132, 118);
            BipolarDisorderCheckBox.Name = "BipolarDisorderCheckBox";
            BipolarDisorderCheckBox.Size = new Size(15, 14);
            BipolarDisorderCheckBox.TabIndex = 21;
            BipolarDisorderCheckBox.UseVisualStyleBackColor = false;
            BipolarDisorderCheckBox.CheckedChanged += BipolarDisorderCheckBox_CheckedChanged;
            // 
            // DepressionCheckBox
            // 
            DepressionCheckBox.AutoSize = true;
            DepressionCheckBox.BackColor = Color.Transparent;
            DepressionCheckBox.Location = new Point(132, 96);
            DepressionCheckBox.Name = "DepressionCheckBox";
            DepressionCheckBox.Size = new Size(15, 14);
            DepressionCheckBox.TabIndex = 10;
            DepressionCheckBox.UseVisualStyleBackColor = false;
            DepressionCheckBox.CheckedChanged += DepressionCheckBox_CheckedChanged;
            // 
            // CHARTPanel2DoneButton
            // 
            CHARTPanel2DoneButton.BackColor = Color.Transparent;
            CHARTPanel2DoneButton.BackgroundImage = (Image)resources.GetObject("CHARTPanel2DoneButton.BackgroundImage");
            CHARTPanel2DoneButton.BackgroundImageLayout = ImageLayout.None;
            CHARTPanel2DoneButton.Location = new Point(641, 326);
            CHARTPanel2DoneButton.Name = "CHARTPanel2DoneButton";
            CHARTPanel2DoneButton.Size = new Size(119, 38);
            CHARTPanel2DoneButton.TabIndex = 20;
            CHARTPanel2DoneButton.UseVisualStyleBackColor = false;
            CHARTPanel2DoneButton.Click += CHARTPanel2DoneButton_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(238, 231, 218);
            label7.Location = new Point(16, 164);
            label7.Name = "label7";
            label7.Size = new Size(238, 16);
            label7.TabIndex = 17;
            label7.Text = "Generalized Anxiety Disorder (GAD)";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            label7.UseMnemonic = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(238, 231, 218);
            label6.Location = new Point(17, 144);
            label6.Name = "label6";
            label6.Size = new Size(132, 16);
            label6.TabIndex = 16;
            label6.Text = "Anxiety Disorders: ";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            label6.UseMnemonic = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.FromArgb(238, 231, 218);
            label5.Location = new Point(3, 117);
            label5.Name = "label5";
            label5.Size = new Size(120, 14);
            label5.TabIndex = 15;
            label5.Text = "2. Bipolar Disorder";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            label5.UseMnemonic = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(238, 231, 218);
            label4.Location = new Point(3, 95);
            label4.Name = "label4";
            label4.Size = new Size(90, 14);
            label4.TabIndex = 14;
            label4.Text = "1. Depression";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            label4.UseMnemonic = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(238, 231, 218);
            label3.Location = new Point(17, 70);
            label3.Name = "label3";
            label3.Size = new Size(113, 16);
            label3.TabIndex = 13;
            label3.Text = "Mood Disorders:";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            label3.UseMnemonic = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(119, 164, 136);
            panel1.Controls.Add(PatientTimeLabel);
            panel1.Controls.Add(PatientDateLabel);
            panel1.Controls.Add(label32);
            panel1.Controls.Add(ChartApointmentTimeComboBox);
            panel1.Controls.Add(ChartDatePicker);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(label10);
            panel1.Location = new Point(455, 15);
            panel1.Name = "panel1";
            panel1.Size = new Size(298, 145);
            panel1.TabIndex = 12;
            panel1.Paint += panel1_Paint;
            // 
            // PatientTimeLabel
            // 
            PatientTimeLabel.AutoSize = true;
            PatientTimeLabel.BackColor = Color.Transparent;
            PatientTimeLabel.Font = new Font("Tahoma", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            PatientTimeLabel.ForeColor = Color.FromArgb(238, 231, 218);
            PatientTimeLabel.Location = new Point(26, 53);
            PatientTimeLabel.Name = "PatientTimeLabel";
            PatientTimeLabel.Size = new Size(147, 18);
            PatientTimeLabel.TabIndex = 30;
            PatientTimeLabel.Text = "Appointment Time:";
            PatientTimeLabel.TextAlign = ContentAlignment.MiddleCenter;
            PatientTimeLabel.UseMnemonic = false;
            PatientTimeLabel.Click += PatientTimeLabel_Click;
            // 
            // PatientDateLabel
            // 
            PatientDateLabel.AutoSize = true;
            PatientDateLabel.BackColor = Color.Transparent;
            PatientDateLabel.Font = new Font("Tahoma", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            PatientDateLabel.ForeColor = Color.FromArgb(238, 231, 218);
            PatientDateLabel.Location = new Point(26, 29);
            PatientDateLabel.Name = "PatientDateLabel";
            PatientDateLabel.Size = new Size(146, 18);
            PatientDateLabel.TabIndex = 29;
            PatientDateLabel.Text = "Appointment Date:";
            PatientDateLabel.TextAlign = ContentAlignment.MiddleCenter;
            PatientDateLabel.UseMnemonic = false;
            PatientDateLabel.Click += PatientDateLabel_Click;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.BackColor = Color.Transparent;
            label32.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label32.ForeColor = Color.FromArgb(238, 231, 218);
            label32.Location = new Point(80, 26);
            label32.Name = "label32";
            label32.Size = new Size(0, 21);
            label32.TabIndex = 28;
            // 
            // ChartApointmentTimeComboBox
            // 
            ChartApointmentTimeComboBox.FormattingEnabled = true;
            ChartApointmentTimeComboBox.Items.AddRange(new object[] { "7-9 am", "9-10 am", "1-3 pm", "3-5 pm" });
            ChartApointmentTimeComboBox.Location = new Point(174, 117);
            ChartApointmentTimeComboBox.Name = "ChartApointmentTimeComboBox";
            ChartApointmentTimeComboBox.Size = new Size(106, 23);
            ChartApointmentTimeComboBox.TabIndex = 27;
            ChartApointmentTimeComboBox.SelectedIndexChanged += ChartApointmentTimeComboBox_SelectedIndexChanged;
            // 
            // ChartDatePicker
            // 
            ChartDatePicker.Location = new Point(80, 94);
            ChartDatePicker.Name = "ChartDatePicker";
            ChartDatePicker.Size = new Size(200, 23);
            ChartDatePicker.TabIndex = 26;
            ChartDatePicker.ValueChanged += ChartDatePicker_ValueChanged;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Tahoma", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label15.ForeColor = Color.WhiteSmoke;
            label15.Location = new Point(26, 117);
            label15.Name = "label15";
            label15.Size = new Size(147, 18);
            label15.TabIndex = 25;
            label15.Text = "Appointment Time:";
            label15.TextAlign = ContentAlignment.MiddleCenter;
            label15.UseMnemonic = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Tahoma", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.WhiteSmoke;
            label14.Location = new Point(26, 96);
            label14.Name = "label14";
            label14.Size = new Size(48, 18);
            label14.TabIndex = 24;
            label14.Text = "Date:";
            label14.TextAlign = ContentAlignment.MiddleCenter;
            label14.UseMnemonic = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.FromArgb(238, 231, 218);
            label13.Location = new Point(38, 73);
            label13.Name = "label13";
            label13.Size = new Size(238, 19);
            label13.TabIndex = 23;
            label13.Text = "FOLLOW UP APPOINTMENT:\r\n";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            label13.UseMnemonic = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.FromArgb(238, 231, 218);
            label10.Location = new Point(38, 3);
            label10.Name = "label10";
            label10.Size = new Size(211, 19);
            label10.TabIndex = 21;
            label10.Text = "SESSION INFORMATION:";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            label10.UseMnemonic = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Tahoma", 12.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(238, 231, 218);
            label2.Location = new Point(17, 36);
            label2.Name = "label2";
            label2.Size = new Size(130, 21);
            label2.TabIndex = 11;
            label2.Text = "ASSESSMENT:";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.UseMnemonic = false;
            // 
            // PatientNumberTextBox
            // 
            PatientNumberTextBox.Location = new Point(170, 11);
            PatientNumberTextBox.Name = "PatientNumberTextBox";
            PatientNumberTextBox.Size = new Size(164, 23);
            PatientNumberTextBox.TabIndex = 10;
            PatientNumberTextBox.TextChanged += PatientNumberTextBox_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Tahoma", 12.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(238, 231, 218);
            label1.Location = new Point(3, 12);
            label1.Name = "label1";
            label1.Size = new Size(170, 21);
            label1.TabIndex = 0;
            label1.Text = "PATIENT NUMBER:";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.UseMnemonic = false;
            // 
            // RecordPanel3
            // 
            RecordPanel3.BackColor = Color.FromArgb(99, 133, 105);
            RecordPanel3.Controls.Add(label11);
            RecordPanel3.Controls.Add(RecordButtonHome);
            RecordPanel3.Controls.Add(pictureBox1);
            RecordPanel3.Controls.Add(RecordGridView);
            RecordPanel3.Location = new Point(228, 53);
            RecordPanel3.Name = "RecordPanel3";
            RecordPanel3.Size = new Size(766, 371);
            RecordPanel3.TabIndex = 10;
            RecordPanel3.Paint += RecordPanel3_Paint;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(493, 108);
            label11.Name = "label11";
            label11.Size = new Size(0, 15);
            label11.TabIndex = 11;
            // 
            // RecordButtonHome
            // 
            RecordButtonHome.BackColor = Color.Transparent;
            RecordButtonHome.BackgroundImage = (Image)resources.GetObject("RecordButtonHome.BackgroundImage");
            RecordButtonHome.BackgroundImageLayout = ImageLayout.None;
            RecordButtonHome.Location = new Point(654, 323);
            RecordButtonHome.Name = "RecordButtonHome";
            RecordButtonHome.Size = new Size(99, 37);
            RecordButtonHome.TabIndex = 11;
            RecordButtonHome.UseVisualStyleBackColor = false;
            RecordButtonHome.Click += RecordButtonHome_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            pictureBox1.Location = new Point(9, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 19);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // RecordGridView
            // 
            RecordGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            RecordGridView.Location = new Point(7, 32);
            RecordGridView.Name = "RecordGridView";
            RecordGridView.RowTemplate.Height = 25;
            RecordGridView.Size = new Size(753, 282);
            RecordGridView.TabIndex = 0;
            RecordGridView.CellContentClick += RecordGridView_CellContentClick;
            // 
            // BANNER1Box
            // 
            BANNER1Box.BackColor = Color.Transparent;
            BANNER1Box.BackgroundImage = (Image)resources.GetObject("BANNER1Box.BackgroundImage");
            BANNER1Box.BackgroundImageLayout = ImageLayout.None;
            BANNER1Box.Location = new Point(12, 7);
            BANNER1Box.Name = "BANNER1Box";
            BANNER1Box.Size = new Size(384, 40);
            BANNER1Box.TabIndex = 8;
            BANNER1Box.TabStop = false;
            // 
            // PatientChartCaution
            // 
            PatientChartCaution.BackColor = Color.Transparent;
            PatientChartCaution.BackgroundImage = (Image)resources.GetObject("PatientChartCaution.BackgroundImage");
            PatientChartCaution.BackgroundImageLayout = ImageLayout.None;
            PatientChartCaution.Location = new Point(48, 258);
            PatientChartCaution.Name = "PatientChartCaution";
            PatientChartCaution.Size = new Size(128, 28);
            PatientChartCaution.TabIndex = 0;
            PatientChartCaution.TabStop = false;
            PatientChartCaution.Click += PatientChartCaution_Click;
            // 
            // PatientChartCautionLabel
            // 
            PatientChartCautionLabel.AutoSize = true;
            PatientChartCautionLabel.BackColor = Color.Transparent;
            PatientChartCautionLabel.Font = new Font("Segoe UI", 8.25F, FontStyle.Italic, GraphicsUnit.Point);
            PatientChartCautionLabel.Location = new Point(6, 298);
            PatientChartCautionLabel.Name = "PatientChartCautionLabel";
            PatientChartCautionLabel.Size = new Size(221, 104);
            PatientChartCautionLabel.TabIndex = 9;
            PatientChartCautionLabel.Text = resources.GetString("PatientChartCautionLabel.Text");
            PatientChartCautionLabel.TextAlign = ContentAlignment.MiddleCenter;
            PatientChartCautionLabel.Click += PatientChartCautionLabel_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // mySqlCommand1
            // 
            mySqlCommand1.CacheAge = 0;
            mySqlCommand1.Connection = null;
            mySqlCommand1.EnableCaching = false;
            mySqlCommand1.Transaction = null;
            // 
            // MHPage4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.EnablePreventFocusChange;
            BackColor = Color.DarkSeaGreen;
            ClientSize = new Size(1004, 436);
            Controls.Add(RecordPanel3);
            Controls.Add(CHARTPanel2);
            Controls.Add(PatientChartCautionLabel);
            Controls.Add(PatientChartCaution);
            Controls.Add(BANNER1Box);
            Controls.Add(APPOINTMENTPanel1);
            Controls.Add(LobbyPicture);
            Controls.Add(Button3label);
            Controls.Add(Button2label);
            Controls.Add(Button1label);
            Controls.Add(APPOINTMENTButton1);
            Controls.Add(CHARTButton2);
            Controls.Add(RECORDButton3);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MHPage4";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MH Appointment System";
            Load += MHPage4_Load;
            ((System.ComponentModel.ISupportInitialize)form1BindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)LobbyPicture).EndInit();
            APPOINTMENTPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)AppointmentDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)Panel1PatientInfoBox).EndInit();
            CHARTPanel2.ResumeLayout(false);
            CHARTPanel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            RecordPanel3.ResumeLayout(false);
            RecordPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)RecordGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)BANNER1Box).EndInit();
            ((System.ComponentModel.ISupportInitialize)PatientChartCaution).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private BindingSource form1BindingSource;
        private Button APPOINTMENTButton1;
        private Button CHARTButton2;
        private Button RECORDButton3;
        private Label Button1label;
        private Label Button2label;
        private Label Button3label;
        private ImageList imageList1;
        private PictureBox LobbyPicture;
        private Panel APPOINTMENTPanel1;
        private PictureBox BANNER1Box;
        private PictureBox Panel1PatientInfoBox;
        private Panel CHARTPanel2;
        private PictureBox PatientChartCaution;
        private Label PatientChartCautionLabel;
        private Label label2;
        private TextBox PatientNumberTextBox;
        private Label label1;
        private Panel panel1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Button CHARTPanel2DoneButton;
        private Label label7;
        private Label label13;
        private Label label10;
        private Label label15;
        private Label label14;
        private ContextMenuStrip contextMenuStrip1;
        private MySql.Data.MySqlClient.MySqlCommand mySqlCommand1;
        private CheckBox DepressionCheckBox;
        private CheckBox SocialAnxietyCheckBox;
        private CheckBox PanicDisorderCheckBox;
        private CheckBox BipolarDisorderCheckBox;
        private Label label17;
        private Label label16;
        private Label label9;
        private Label label8;
        private Label label18;
        private CheckBox PTSDCheckBox;
        private CheckBox OCDCheckBox;
        private CheckBox EatingDisorderCheckBox;
        private CheckBox PsychoticDisorderCheckBox;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label28;
        private Label label27;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private Label label22;
        private CheckBox SelfharmCheckbox;
        private CheckBox SleepDisorderCheckBox;
        private CheckBox PersonalityandBehaviorDisorderCheckbox;
        private CheckBox SubstanceRelatedCheckBox;
        private CheckBox ICandADCheckBox;
        private Label label31;
        private Label label30;
        private Label label29;
        private DateTimePicker ChartDatePicker;
        private ComboBox ChartApointmentTimeComboBox;
        private Label label32;
        private DataGridView AppointmentDataGridView;
        private Label PatientTimeLabel;
        private Label PatientDateLabel;
        private Panel RecordPanel3;
        private DataGridView RecordGridView;
        private PictureBox pictureBox1;
        private Button RecordButtonHome;
        private Label label11;
    }
}