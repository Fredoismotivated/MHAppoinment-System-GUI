﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MHAppointmentIndex
{
    public partial class MHAPage3Login : Form
    {
        public MHAPage3Login()
        {
            InitializeComponent();
        }

        private void userTXTBX_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwordTXTBX_TextChanged(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            String username = userTXTBX.Text;
            String password = passwordTXTBX.Text;
            // if else nalang ang hirap naman kung gagawan ko pato ng user taena isang admin lang naman kailangan magaccess ng sht dito
            if (username == "mha.admin" && password == "mha.admin1234")
            { //mha.admin - mha1234
                this.Hide(); // magh-hide current page
                MHPage4 f4 = new MHPage4();
                f4.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Wrong user or password!");
            }

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide(); // magh-hide current page
            MHPage2 f2 = new MHPage2();
            f2.ShowDialog();
            this.Close();
        }

        private void WarningLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
