-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2024 at 03:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mhpatients`
--

-- --------------------------------------------------------

--
-- Table structure for table `mhpatientsrecords`
--

CREATE TABLE `mhpatientsrecords` (
  `RecordNumber` int(11) NOT NULL,
  `PatientNumber` int(150) NOT NULL,
  `Depression` tinyint(1) NOT NULL,
  `BipolarDisorder` tinyint(1) NOT NULL,
  `PanicDisorder` tinyint(1) NOT NULL,
  `SocialAnxiety` tinyint(1) NOT NULL,
  `OCD` tinyint(1) NOT NULL,
  `PTSD` tinyint(1) NOT NULL,
  `PsychoticDisorder` tinyint(1) NOT NULL,
  `EatingDisorder` tinyint(1) NOT NULL,
  `ICandAD` tinyint(1) NOT NULL,
  `SubstanceRelated` tinyint(1) NOT NULL,
  `PersonalityBehaviorDisorder` tinyint(1) NOT NULL,
  `SleepDisorder` tinyint(1) NOT NULL,
  `SelfHarm` tinyint(1) NOT NULL,
  `AppointmentDate1` date NOT NULL,
  `AppointmentTime1` varchar(20) DEFAULT NULL,
  `AppointmentDate2` date NOT NULL,
  `AppointmentTime2` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mhpatientsrecords`
--

INSERT INTO `mhpatientsrecords` (`RecordNumber`, `PatientNumber`, `Depression`, `BipolarDisorder`, `PanicDisorder`, `SocialAnxiety`, `OCD`, `PTSD`, `PsychoticDisorder`, `EatingDisorder`, `ICandAD`, `SubstanceRelated`, `PersonalityBehaviorDisorder`, `SleepDisorder`, `SelfHarm`, `AppointmentDate1`, `AppointmentTime1`, `AppointmentDate2`, `AppointmentTime2`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-01-19', '00:00:07', '2024-01-21', '00:00:07'),
(2, 2, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, '2024-01-19', '00:00:09', '2024-01-21', '00:00:03'),
(3, 2, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, '2024-01-19', '00:00:09', '2024-01-21', '00:00:03'),
(4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-01-19', '00:00:07', '2024-01-21', '00:00:07'),
(5, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2024-01-21', '00:00:07', '2024-01-22', '00:00:03'),
(6, 4, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, '2024-01-21', '00:00:07', '2024-01-22', '00:00:07'),
(7, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-01-19', '9-10 am', '2024-02-03', '7-9 am'),
(8, 13, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2024-02-04', '8 am - 9 am', '2024-02-05', '7-9 am'),
(9, 14, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2024-02-04', '8 am - 9 am', '2024-02-04', '7-9 am'),
(10, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-02-11', '8am - 1pm', '2024-02-06', '7-9 am'),
(11, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2024-01-19', '7-9 am', '2024-02-05', '');

-- --------------------------------------------------------

--
-- Table structure for table `patientappointment`
--

CREATE TABLE `patientappointment` (
  `PatientNumber` int(150) NOT NULL,
  `surname` varchar(150) NOT NULL,
  `firstname` varchar(150) NOT NULL,
  `Sex` varchar(150) NOT NULL,
  `age` int(150) NOT NULL,
  `contact` bigint(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `address` varchar(150) NOT NULL,
  `TimeRange` varchar(150) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patientappointment`
--

INSERT INTO `patientappointment` (`PatientNumber`, `surname`, `firstname`, `Sex`, `age`, `contact`, `email`, `address`, `TimeRange`, `Date`) VALUES
(1, 'Doe', 'John', 'Male', 34, 2147483647, 'email@yahoo.com', 'Silang Cavite', '7-9 am', '2024-01-19'),
(2, 'Numbers', 'Numbers', 'Male', 44, 9152104027, 'Numbers@gmail.com', 'Numbers', '9-10 am', '2024-01-19'),
(3, 'test3', 'test3', 'Male', 44, 9152104027, 'rfdededed@gmail.com', 'cavite', '7-9 am', '2024-01-21'),
(4, 'test', 'test', 'Male', 19, 9123456789, 'test@gmail.com', 'cavite', '7-9 am', '2024-01-21'),
(5, 'Weekend', 'TestSched', 'Male', 18, 9123456789, 'TestSched@gmail.com', 'SanaGumanaSilangCavite', '8am - 1pm', '2024-02-11'),
(6, 'Testnumber', 'Number', 'Female', 55, 9123456789, 'sanagumagana@yahoo.com', 'jan lang', '3 pm - 4 pm', '2024-02-05'),
(7, 'numberzero', 'numberzero', 'Male', 18, 9123456789, 'numberzero@yahoo.com', 'numberzero', '8 am - 9 am', '2024-02-05'),
(8, 'mayzeronaba', 'mayzeronaba', 'Male', 18, 9123456789, 'mayzeronaba@gmail.com', 'mayzeronaba', '10 am - 11 am', '2024-02-05'),
(9, 'oknaba', 'oknaba', 'Female', 18, 9123456789, 'oknaba@gmail.com', 'oknaba', '8 am - 9 am', '2024-02-06'),
(10, 'Fredo', 'Fredo', 'Male', 20, 9123456789, 'fredo@gmail.com', 'janlang', '9 am - 10 am', '2024-02-06'),
(11, 'Try', 'Try', 'Male', 11, 9123456789, '@gmail.com', '', '8 am - 9 am', '2024-01-29'),
(12, 'Try', 'Try', 'Male', 20, 9123456789, 'try@gmail.com', 'trylang', '2 pm - 3 pm', '2024-03-11'),
(13, 'Bigletter', 'Bigletter', 'Male', 12, 9123456789, 'fredrickmasikat@gmail.com', 'janlang', '8 am - 9 am', '2024-02-04'),
(14, 'Haha', 'Haha', 'Male', 77, 9123456789, 'haha@gmail.com', 'haha', '8 am - 9 am', '2024-02-04'),
(15, 'Haha', 'Hhaha', 'Female', 77, 9123456789, 'hahatry@gmail.com', 'janlang', '8 am - 9 am', '2024-02-04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mhpatientsrecords`
--
ALTER TABLE `mhpatientsrecords`
  ADD PRIMARY KEY (`RecordNumber`);

--
-- Indexes for table `patientappointment`
--
ALTER TABLE `patientappointment`
  ADD PRIMARY KEY (`PatientNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mhpatientsrecords`
--
ALTER TABLE `mhpatientsrecords`
  MODIFY `RecordNumber` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `patientappointment`
--
ALTER TABLE `patientappointment`
  MODIFY `PatientNumber` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
