﻿namespace MHAppointmentIndex
{
    partial class MHAPage3Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MHAPage3Login));
            userTXTBX = new TextBox();
            passwordTXTBX = new TextBox();
            LoginButton = new Button();
            BackButton = new Button();
            WarningLabel = new Label();
            UserLabel = new Label();
            PasswordLabel = new Label();
            SuspendLayout();
            // 
            // userTXTBX
            // 
            userTXTBX.Location = new Point(634, 195);
            userTXTBX.Name = "userTXTBX";
            userTXTBX.Size = new Size(198, 23);
            userTXTBX.TabIndex = 0;
            userTXTBX.TextChanged += userTXTBX_TextChanged;
            // 
            // passwordTXTBX
            // 
            passwordTXTBX.Location = new Point(634, 246);
            passwordTXTBX.Name = "passwordTXTBX";
            passwordTXTBX.PasswordChar = '*';
            passwordTXTBX.Size = new Size(198, 23);
            passwordTXTBX.TabIndex = 1;
            passwordTXTBX.TextChanged += passwordTXTBX_TextChanged;
            // 
            // LoginButton
            // 
            LoginButton.BackgroundImage = (Image)resources.GetObject("LoginButton.BackgroundImage");
            LoginButton.BackgroundImageLayout = ImageLayout.Center;
            LoginButton.Location = new Point(670, 290);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(142, 55);
            LoginButton.TabIndex = 5;
            LoginButton.UseVisualStyleBackColor = true;
            LoginButton.Click += LoginButton_Click;
            // 
            // BackButton
            // 
            BackButton.BackgroundImage = (Image)resources.GetObject("BackButton.BackgroundImage");
            BackButton.BackgroundImageLayout = ImageLayout.Center;
            BackButton.Location = new Point(183, 379);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(132, 48);
            BackButton.TabIndex = 6;
            BackButton.UseVisualStyleBackColor = true;
            BackButton.Click += BackButton_Click;
            // 
            // WarningLabel
            // 
            WarningLabel.AutoSize = true;
            WarningLabel.BackColor = Color.Transparent;
            WarningLabel.Font = new Font("Tahoma", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            WarningLabel.ForeColor = Color.Black;
            WarningLabel.Location = new Point(91, 330);
            WarningLabel.Name = "WarningLabel";
            WarningLabel.Size = new Size(335, 46);
            WarningLabel.TabIndex = 7;
            WarningLabel.Text = " Please select 'back' if you accidentally \r\nclicked the admin button";
            WarningLabel.TextAlign = ContentAlignment.MiddleCenter;
            WarningLabel.Click += WarningLabel_Click;
            // 
            // UserLabel
            // 
            UserLabel.AutoSize = true;
            UserLabel.BackColor = Color.Transparent;
            UserLabel.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            UserLabel.Location = new Point(634, 177);
            UserLabel.Name = "UserLabel";
            UserLabel.Size = new Size(31, 15);
            UserLabel.TabIndex = 8;
            UserLabel.Text = "User";
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.BackColor = Color.Transparent;
            PasswordLabel.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            PasswordLabel.Location = new Point(634, 228);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(59, 15);
            PasswordLabel.TabIndex = 9;
            PasswordLabel.Text = "Password";
            // 
            // MHAPage3Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSeaGreen;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1004, 436);
            Controls.Add(PasswordLabel);
            Controls.Add(UserLabel);
            Controls.Add(WarningLabel);
            Controls.Add(BackButton);
            Controls.Add(LoginButton);
            Controls.Add(userTXTBX);
            Controls.Add(passwordTXTBX);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MHAPage3Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MH Appointment System";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox userTXTBX;
        private TextBox passwordTXTBX;
        private Button LoginButton;
        private Button BackButton;
        private Label WarningLabel;
        private Label UserLabel;
        private Label PasswordLabel;
    }
}