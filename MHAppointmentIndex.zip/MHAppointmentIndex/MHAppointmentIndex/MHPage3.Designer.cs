﻿namespace MHAppointmentIndex
{
    partial class MHPage3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MHPage3));
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            SurnameTXTBX = new TextBox();
            FirstnameTXTBX = new TextBox();
            label1 = new Label();
            label2 = new Label();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            AgeTXTBX = new TextBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            ContactNoTXTBX = new TextBox();
            pictureBox7 = new PictureBox();
            TimeComboBox = new ComboBox();
            label3 = new Label();
            label4 = new Label();
            pictureBox8 = new PictureBox();
            EmailAddTXTBX = new TextBox();
            button1 = new Button();
            button2 = new Button();
            monthCalendar1 = new MonthCalendar();
            AddressTXTBX = new TextBox();
            GenderComboBox = new ComboBox();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            pictureBox1.Location = new Point(26, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(373, 38);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.BackgroundImageLayout = ImageLayout.None;
            pictureBox2.Location = new Point(38, 65);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(81, 32);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // SurnameTXTBX
            // 
            SurnameTXTBX.Location = new Point(38, 118);
            SurnameTXTBX.Name = "SurnameTXTBX";
            SurnameTXTBX.Size = new Size(191, 23);
            SurnameTXTBX.TabIndex = 2;
            SurnameTXTBX.TextChanged += SurnameTXTBX_TextChanged;
            // 
            // FirstnameTXTBX
            // 
            FirstnameTXTBX.Location = new Point(274, 118);
            FirstnameTXTBX.Name = "FirstnameTXTBX";
            FirstnameTXTBX.Size = new Size(191, 23);
            FirstnameTXTBX.TabIndex = 3;
            FirstnameTXTBX.TextChanged += FirstnameTXTBX_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(26, 88);
            label1.Name = "label1";
            label1.Size = new Size(56, 15);
            label1.TabIndex = 4;
            label1.Text = "Surname";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(262, 88);
            label2.Name = "label2";
            label2.Size = new Size(66, 15);
            label2.TabIndex = 5;
            label2.Text = "First Name";
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.BackgroundImage = (Image)resources.GetObject("pictureBox3.BackgroundImage");
            pictureBox3.BackgroundImageLayout = ImageLayout.None;
            pictureBox3.Location = new Point(26, 136);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(54, 23);
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Anchor = AnchorStyles.None;
            pictureBox4.BackColor = Color.Transparent;
            pictureBox4.BackgroundImage = (Image)resources.GetObject("pictureBox4.BackgroundImage");
            pictureBox4.BackgroundImageLayout = ImageLayout.None;
            pictureBox4.Location = new Point(262, 137);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(59, 22);
            pictureBox4.TabIndex = 7;
            pictureBox4.TabStop = false;
            // 
            // AgeTXTBX
            // 
            AgeTXTBX.Location = new Point(274, 176);
            AgeTXTBX.Name = "AgeTXTBX";
            AgeTXTBX.Size = new Size(191, 23);
            AgeTXTBX.TabIndex = 9;
            AgeTXTBX.TextChanged += AgeTXTBX_TextChanged;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Transparent;
            pictureBox5.BackgroundImage = (Image)resources.GetObject("pictureBox5.BackgroundImage");
            pictureBox5.BackgroundImageLayout = ImageLayout.None;
            pictureBox5.Location = new Point(495, 61);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(127, 24);
            pictureBox5.TabIndex = 10;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.Transparent;
            pictureBox6.BackgroundImage = (Image)resources.GetObject("pictureBox6.BackgroundImage");
            pictureBox6.BackgroundImageLayout = ImageLayout.None;
            pictureBox6.Location = new Point(26, 201);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(222, 24);
            pictureBox6.TabIndex = 12;
            pictureBox6.TabStop = false;
            // 
            // ContactNoTXTBX
            // 
            ContactNoTXTBX.Location = new Point(26, 241);
            ContactNoTXTBX.Name = "ContactNoTXTBX";
            ContactNoTXTBX.Size = new Size(191, 23);
            ContactNoTXTBX.TabIndex = 13;
            ContactNoTXTBX.TextChanged += ContactNoTXTBX_TextChanged;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.Transparent;
            pictureBox7.BackgroundImage = (Image)resources.GetObject("pictureBox7.BackgroundImage");
            pictureBox7.BackgroundImageLayout = ImageLayout.None;
            pictureBox7.Location = new Point(262, 202);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(128, 23);
            pictureBox7.TabIndex = 14;
            pictureBox7.TabStop = false;
            // 
            // TimeComboBox
            // 
            TimeComboBox.FormattingEnabled = true;
            TimeComboBox.Location = new Point(262, 241);
            TimeComboBox.Name = "TimeComboBox";
            TimeComboBox.Size = new Size(121, 23);
            TimeComboBox.TabIndex = 15;
            TimeComboBox.Text = "Choose a time";
            TimeComboBox.SelectedIndexChanged += TimeComboBox_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(262, 225);
            label3.Name = "label3";
            label3.Size = new Size(34, 15);
            label3.TabIndex = 16;
            label3.Text = "Time";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(495, 205);
            label4.Name = "label4";
            label4.Size = new Size(29, 15);
            label4.TabIndex = 17;
            label4.Text = "Day";
            label4.Click += label4_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.Transparent;
            pictureBox8.BackgroundImage = (Image)resources.GetObject("pictureBox8.BackgroundImage");
            pictureBox8.BackgroundImageLayout = ImageLayout.None;
            pictureBox8.Location = new Point(26, 270);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(191, 23);
            pictureBox8.TabIndex = 20;
            pictureBox8.TabStop = false;
            // 
            // EmailAddTXTBX
            // 
            EmailAddTXTBX.Location = new Point(26, 299);
            EmailAddTXTBX.Multiline = true;
            EmailAddTXTBX.Name = "EmailAddTXTBX";
            EmailAddTXTBX.Size = new Size(191, 80);
            EmailAddTXTBX.TabIndex = 21;
            EmailAddTXTBX.TextChanged += EmailAddTXTBX_TextChanged;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.None;
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.Location = new Point(783, 155);
            button1.Name = "button1";
            button1.Size = new Size(108, 39);
            button1.TabIndex = 22;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.None;
            button2.BackgroundImage = (Image)resources.GetObject("button2.BackgroundImage");
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Location = new Point(795, 229);
            button2.Name = "button2";
            button2.Size = new Size(108, 39);
            button2.TabIndex = 23;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // monthCalendar1
            // 
            monthCalendar1.Location = new Point(495, 225);
            monthCalendar1.Name = "monthCalendar1";
            monthCalendar1.TabIndex = 24;
            monthCalendar1.DateChanged += monthCalendar1_DateChanged;
            // 
            // AddressTXTBX
            // 
            AddressTXTBX.Location = new Point(495, 88);
            AddressTXTBX.Multiline = true;
            AddressTXTBX.Name = "AddressTXTBX";
            AddressTXTBX.Size = new Size(224, 88);
            AddressTXTBX.TabIndex = 25;
            AddressTXTBX.TextChanged += AddressTXTBX_TextChanged;
            // 
            // GenderComboBox
            // 
            GenderComboBox.FormattingEnabled = true;
            GenderComboBox.Items.AddRange(new object[] { "", "Male", "Female" });
            GenderComboBox.Location = new Point(38, 176);
            GenderComboBox.Name = "GenderComboBox";
            GenderComboBox.Size = new Size(191, 23);
            GenderComboBox.TabIndex = 26;
            GenderComboBox.SelectedIndexChanged += GenderComboBox_SelectedIndexChanged;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(99, 133, 105);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(AddressTXTBX);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(monthCalendar1);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(EmailAddTXTBX);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(ContactNoTXTBX);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(TimeComboBox);
            panel1.Controls.Add(pictureBox8);
            panel1.Controls.Add(pictureBox7);
            panel1.Controls.Add(pictureBox6);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(980, 412);
            panel1.TabIndex = 27;
            panel1.Paint += panel1_Paint;
            // 
            // MHPage3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSeaGreen;
            ClientSize = new Size(1004, 436);
            Controls.Add(GenderComboBox);
            Controls.Add(button2);
            Controls.Add(AgeTXTBX);
            Controls.Add(FirstnameTXTBX);
            Controls.Add(SurnameTXTBX);
            Controls.Add(pictureBox2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MHPage3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MH Appointment System";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private TextBox SurnameTXTBX;
        private TextBox FirstnameTXTBX;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private TextBox AgeTXTBX;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private TextBox ContactNoTXTBX;
        private PictureBox pictureBox7;
        private ComboBox TimeComboBox;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox8;
        private TextBox EmailAddTXTBX;
        private Button button1;
        private Button button2;
        private MonthCalendar monthCalendar1;
        private TextBox AddressTXTBX;
        private ComboBox GenderComboBox;
        private Panel panel1;
    }
}