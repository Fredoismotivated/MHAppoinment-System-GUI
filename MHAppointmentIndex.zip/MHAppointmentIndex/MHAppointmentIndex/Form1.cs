namespace MHAppointmentIndex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //PROCEED BUTTON
        {
            this.Hide(); // magh-hide current page
            MHPage2 f2 = new MHPage2();
            f2.ShowDialog();
            this.Close();
        }
    }
}