﻿namespace MHAppointmentIndex
{
    partial class MHPage2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MHPage2));
            AdminButton = new Button();
            AnswerFormButton = new Button();
            label1 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // AdminButton
            // 
            AdminButton.Anchor = AnchorStyles.None;
            AdminButton.BackColor = Color.DarkSeaGreen;
            AdminButton.BackgroundImage = (Image)resources.GetObject("AdminButton.BackgroundImage");
            AdminButton.Location = new Point(709, 371);
            AdminButton.Name = "AdminButton";
            AdminButton.Size = new Size(126, 39);
            AdminButton.TabIndex = 0;
            AdminButton.UseVisualStyleBackColor = false;
            AdminButton.Click += button1_Click;
            // 
            // AnswerFormButton
            // 
            AnswerFormButton.Anchor = AnchorStyles.None;
            AnswerFormButton.BackColor = Color.DarkSeaGreen;
            AnswerFormButton.BackgroundImage = (Image)resources.GetObject("AnswerFormButton.BackgroundImage");
            AnswerFormButton.Location = new Point(709, 148);
            AnswerFormButton.Name = "AnswerFormButton";
            AnswerFormButton.Size = new Size(188, 42);
            AnswerFormButton.TabIndex = 1;
            AnswerFormButton.UseVisualStyleBackColor = false;
            AnswerFormButton.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(709, 130);
            label1.Name = "label1";
            label1.Size = new Size(128, 15);
            label1.TabIndex = 2;
            label1.Text = "Make an appointment!";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(709, 235);
            label2.Name = "label2";
            label2.Size = new Size(126, 15);
            label2.TabIndex = 3;
            label2.Text = "Doctor James Schedule";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(175, 200, 173);
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            pictureBox1.Location = new Point(699, 254);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(293, 114);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // MHPage2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1004, 436);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(AnswerFormButton);
            Controls.Add(AdminButton);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MHPage2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MH Appointment System";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button AdminButton;
        private Button AnswerFormButton;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox1;
    }
}