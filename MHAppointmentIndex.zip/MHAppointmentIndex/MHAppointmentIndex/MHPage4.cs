﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace MHAppointmentIndex
{
    public partial class MHPage4 : Form
    {
        // MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password");
        public MHPage4()
        {
            InitializeComponent();
            LoadAndDisplayData(); //LoadAndDisplay function - para to sa datagrid
            PatientNumberTextBox.TextChanged += PatientNumberTextBox_TextChanged;
            LoadAndDisplayRecords(); // last function - para load at display records table ././././././././. ./.
        }

        private void MHPage4_Load(object sender, EventArgs e)
        {
            LobbyPicture.Visible = true;
            APPOINTMENTPanel1.Visible = false;
            CHARTPanel2.Visible = false;
            PatientChartCaution.Visible = false;
            PatientChartCautionLabel.Visible = false;
            AppointmentDataGridView.Visible = false;
            RecordPanel3.Visible = false;
        }
        private void APPOINTMENTButton1_Click_1(object sender, EventArgs e)
        {
            Button1label.ForeColor = System.Drawing.Color.White; //Clicked indicator
            Button2label.ForeColor = System.Drawing.Color.Black; //Clicked indicator remover
            Button3label.ForeColor = System.Drawing.Color.Black; //Clicked indicator remover
            LobbyPicture.Visible = false;
            APPOINTMENTPanel1.Visible = true;
            AppointmentDataGridView.Visible = true;
            CHARTPanel2.Visible = false;
            PatientChartCaution.Visible = false;
            PatientChartCautionLabel.Visible = false;
            RecordPanel3.Visible = false;
        }

        private void CHARTButton2_Click_1(object sender, EventArgs e)
        {
            Button2label.ForeColor = System.Drawing.Color.White; //Clicked indicator
            Button1label.ForeColor = System.Drawing.Color.Black; //Clicked indicator remover
            Button3label.ForeColor = System.Drawing.Color.Black; //Clicked indicator remover
            APPOINTMENTPanel1.Visible = false;
            AppointmentDataGridView.Visible = false;
            CHARTPanel2.Visible = true;
            PatientChartCaution.Visible = true;
            PatientChartCautionLabel.Visible = true;
            RecordPanel3.Visible = false;
        }

        private void RECORDButton3_Click_1(object sender, EventArgs e)
        {
            Button3label.ForeColor = System.Drawing.Color.White; //Clicked indicator
            Button1label.ForeColor = System.Drawing.Color.Black; //Clicked indicator remover
            Button2label.ForeColor = System.Drawing.Color.Black; //Clicked indicator remover
            APPOINTMENTPanel1.Visible = false;
            AppointmentDataGridView.Visible = false;
            CHARTPanel2.Visible = false;
            PatientChartCaution.Visible = false;
            PatientChartCautionLabel.Visible = false;
            RecordPanel3.Visible = true;
        }

        private void LobbyPicture_Click(object sender, EventArgs e)
        {

        }

        private void APPOINTMENTPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Button1label_Click(object sender, EventArgs e)
        {

        }

        private void Button2label_Click(object sender, EventArgs e)
        {

        }

        private void Button3label_Click(object sender, EventArgs e)
        {

        }

        private void CHARTPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PatientChartCaution_Click(object sender, EventArgs e)
        {

        }

        private void PatientChartCautionLabel_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AppointmentDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        //gumawa ako ng method o function para maextract laman ng database table - para magdisplay sa datagrid
        private void LoadAndDisplayData()
        {
            try
            {
                string connectionString = "datasource=127.0.0.1;database=mhpatients;port=3306;username=root;password=";
                string query = "SELECT * FROM patientappointment";

                using (MySqlConnection connection = new MySqlConnection(connectionString))
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection))
                {
                    DataTable patientappointment = new DataTable();
                    adapter.Fill(patientappointment);

                    foreach (DataColumn column in patientappointment.Columns)
                    {
                        if (column.DataType == typeof(DateTime) || column.DataType == typeof(DateTime?))
                        {
                            foreach (DataRow row in patientappointment.Rows)
                            {
                                if (!Convert.IsDBNull(row[column]))
                                {
                                    row[column] = Convert.ToDateTime(row[column], CultureInfo.InvariantCulture);
                                }
                            }
                        }
                    }

                    AppointmentDataGridView.DataSource = patientappointment;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }



        private void PatientNumberTextBox_TextChanged(object? sender, EventArgs e)
        {
            try
            {
                // start ng connection papunta database
                string connectionString = "datasource=127.0.0.1;database=mhpatients;port=3306;username=root;password=";
                string query = "SELECT Date, TimeRange FROM patientappointment WHERE PatientNumber = @patientNumber";

                // eto ata yung mismong connection sa database tsaka pangcreate ng command? diko sure e laging may ganto sa unahan ng code sa yt tsaka stack overflow
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.Add("@patientNumber", MySqlDbType.Int32).Value = Convert.ToInt32(PatientNumberTextBox.Text);

                    // eto yung start ng connection pa database parang .Open(); kase magoopen na sya ng connection 
                    connection.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        // naka if else - eto yung mismong condition para magdisplay yung date at time galing table sa database papuntang label
                        if (reader.Read())
                        {
                            PatientDateLabel.Text = $"Appointment Date: {reader.GetDateTime(0):yyyy-MM-dd}";
                            PatientTimeLabel.Text = $"Appointment Time: {reader.GetString(1)}";
                        }
                        else // else condition kung wala - pero mostlikely dina to kailangan kase hindi naman pwedeng walang appointment date at time
                        {
                            PatientDateLabel.Text = "Appointment Date: N/A";
                            PatientTimeLabel.Text = "Appointment Time: N/A";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void PatientDateLabel_Click(object sender, EventArgs e)
        {

        }

        private void PatientTimeLabel_Click(object sender, EventArgs e)
        {

        }

        private void DepressionCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BipolarDisorderCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void PanicDisorderCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void SocialAnxietyCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void OCDCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void PTSDCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void PsychoticDisorderCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void EatingDisorderCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ICandADCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void SubstanceRelatedCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void PersonalityandBehaviorDisorderCheckbox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void SleepDisorderCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void SelfharmCheckbox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ChartDatePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void ChartApointmentTimeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CHARTPanel2DoneButton_Click(object sender, EventArgs e)
        {
            try
            {
                // pangkuha ng values ng checkboxes, diko alam kung ittry ko pato iconvert pa true or false talaga o check or no na display sa table ang hirap na kase e 
                bool depression = DepressionCheckBox.Checked;
                bool bipolarDisorder = BipolarDisorderCheckBox.Checked;
                bool panicDisorder = PanicDisorderCheckBox.Checked;
                bool socialAnxiety = SocialAnxietyCheckBox.Checked;
                bool ocd = OCDCheckBox.Checked;
                bool ptsd = PTSDCheckBox.Checked;
                bool psychoticDisorder = PsychoticDisorderCheckBox.Checked;
                bool eatingDisorder = EatingDisorderCheckBox.Checked;
                bool icAndAD = ICandADCheckBox.Checked;
                bool substanceRelated = SubstanceRelatedCheckBox.Checked;
                bool personalityBehaviorDisorder = PersonalityandBehaviorDisorderCheckbox.Checked;
                bool sleepDisorder = SleepDisorderCheckBox.Checked;
                bool selfHarm = SelfharmCheckbox.Checked;

                // pangkuha ng napiling date at time para sa second appointment
                DateTime secondAppointmentDate = ChartDatePicker.Value.Date;
                string secondAppointmentTime = ChartApointmentTimeComboBox.Text;

                // eto yung kukuha ng patient number galing sa textbox hindi na sa database para madali na gawa kasama na agad ng patient number gawa ng display data method sa taas
                int patientNumber = Convert.ToInt32(PatientNumberTextBox.Text);

                // eto yung kukuha ng appointment date and time galing sa labels
                DateTime firstAppointmentDate = DateTime.MinValue;
                string firstAppointmentTime = "";

                if (!string.IsNullOrEmpty(PatientDateLabel.Text) && !string.IsNullOrEmpty(PatientTimeLabel.Text))
                {
                    firstAppointmentDate = DateTime.ParseExact(PatientDateLabel.Text.Substring(18), "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    firstAppointmentTime = PatientTimeLabel.Text.Substring(18);
                }

                // connection string yata tawag dito
                string connectionString = "datasource=127.0.0.1;database=mhpatients;port=3306;username=root;password=";

                // SQL query para ma-insert data sa mhpatientsrecords table
                string query = @"INSERT INTO mhpatientsrecords (PatientNumber, Depression, BipolarDisorder, PanicDisorder,
                        SocialAnxiety, OCD, PTSD, PsychoticDisorder, EatingDisorder, ICandAD, SubstanceRelated,
                        PersonalityBehaviorDisorder, SleepDisorder, SelfHarm, AppointmentDate1, AppointmentTime1,
                        AppointmentDate2, AppointmentTime2) 
                        VALUES (@PatientNumber, @Depression, @BipolarDisorder, @PanicDisorder, @SocialAnxiety, @OCD,
                        @PTSD, @PsychoticDisorder, @EatingDisorder, @ICandAD, @SubstanceRelated, 
                        @PersonalityBehaviorDisorder, @SleepDisorder, @SelfHarm, @AppointmentDate1, @AppointmentTime1,
                        @AppointmentDate2, @AppointmentTime2)";

                using (MySqlConnection connection = new MySqlConnection(connectionString))
                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    // parameters para sa SQL query madugo dugong part to 
                    cmd.Parameters.AddWithValue("@PatientNumber", patientNumber);
                    cmd.Parameters.AddWithValue("@Depression", depression);
                    cmd.Parameters.AddWithValue("@BipolarDisorder", bipolarDisorder);
                    cmd.Parameters.AddWithValue("@PanicDisorder", panicDisorder);
                    cmd.Parameters.AddWithValue("@SocialAnxiety", socialAnxiety);
                    cmd.Parameters.AddWithValue("@OCD", ocd);
                    cmd.Parameters.AddWithValue("@PTSD", ptsd);
                    cmd.Parameters.AddWithValue("@PsychoticDisorder", psychoticDisorder);
                    cmd.Parameters.AddWithValue("@EatingDisorder", eatingDisorder);
                    cmd.Parameters.AddWithValue("@ICandAD", icAndAD);
                    cmd.Parameters.AddWithValue("@SubstanceRelated", substanceRelated);
                    cmd.Parameters.AddWithValue("@PersonalityBehaviorDisorder", personalityBehaviorDisorder);
                    cmd.Parameters.AddWithValue("@SleepDisorder", sleepDisorder);
                    cmd.Parameters.AddWithValue("@SelfHarm", selfHarm);
                    cmd.Parameters.AddWithValue("@AppointmentDate1", firstAppointmentDate);
                    cmd.Parameters.AddWithValue("@AppointmentTime1", firstAppointmentTime);
                    cmd.Parameters.AddWithValue("@AppointmentDate2", secondAppointmentDate);
                    cmd.Parameters.AddWithValue("@AppointmentTime2", secondAppointmentTime);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data inserted successfully into mhpatientsrecords table.");
                    ClearInputFields(); // method para maclear lahat pagtapos mapindot done button
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void ClearInputFields() //tinatawag tong method na to para maclear lahat ng current na nakacheck sa panel2 pagkatapos maclick done
        {

            PatientNumberTextBox.Clear();
            DepressionCheckBox.Checked = false; // false kase bool gamit ko sa textboxes kaya 1 o 0 lang nasa table ng patient records
            BipolarDisorderCheckBox.Checked = false;
            PanicDisorderCheckBox.Checked = false;
            SocialAnxietyCheckBox.Checked = false;
            OCDCheckBox.Checked = false;
            PTSDCheckBox.Checked = false;
            PsychoticDisorderCheckBox.Checked = false;
            EatingDisorderCheckBox.Checked = false;
            ICandADCheckBox.Checked = false;
            SubstanceRelatedCheckBox.Checked = false;
            PersonalityandBehaviorDisorderCheckbox.Checked = false;
            SleepDisorderCheckBox.Checked = false;
            SelfharmCheckbox.Checked = false;
            ChartDatePicker.Value = DateTime.Now; //kung ibang araw yung napili dito babalik sya sa current date - yun yung pinaka default nya
            ChartApointmentTimeComboBox.SelectedIndex = -1;
        }

        // fuck last panel na tapos narin ang kalbaryo ko wahahaha 
        // PANEL 3
        private void RecordPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void RecordGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void LoadAndDisplayRecords()
        {
            try
            {
                string connectionString = "datasource=127.0.0.1;database=mhpatients;port=3306;username=root;password=";
                string query = "SELECT * FROM mhpatientsrecords";

                using (MySqlConnection connection = new MySqlConnection(connectionString))
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection))
                {
                    DataTable mhpatientsrecords = new DataTable();
                    adapter.Fill(mhpatientsrecords);

                    // Clear any existing columns in the DataGridView
                    RecordGridView.Columns.Clear();

                    // Bind the DataTable directly to the DataGridView
                    RecordGridView.DataSource = mhpatientsrecords;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }




        private void RecordButtonHome_Click(object sender, EventArgs e) //PAPUNTANG FIRST PAGE
        {
            this.Hide(); // magh-hide current page
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void AppointmentDataGridView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

