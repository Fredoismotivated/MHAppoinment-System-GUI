﻿namespace MHAppointmentIndex
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            ProceedButton = new Button();
            SuspendLayout();
            // 
            // ProceedButton
            // 
            ProceedButton.AllowDrop = true;
            ProceedButton.Anchor = AnchorStyles.None;
            ProceedButton.BackColor = Color.DarkSeaGreen;
            ProceedButton.BackgroundImage = (Image)resources.GetObject("ProceedButton.BackgroundImage");
            ProceedButton.BackgroundImageLayout = ImageLayout.None;
            ProceedButton.Location = new Point(605, 355);
            ProceedButton.Name = "ProceedButton";
            ProceedButton.Size = new Size(195, 48);
            ProceedButton.TabIndex = 0;
            ProceedButton.UseVisualStyleBackColor = false;
            ProceedButton.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1004, 436);
            Controls.Add(ProceedButton);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MH Appointment System";
            ResumeLayout(false);
        }

        #endregion

        private Button ProceedButton;
    }
}